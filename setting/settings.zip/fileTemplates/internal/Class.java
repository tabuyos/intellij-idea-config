#if(false)
#parse("LICENSE_HEADER.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("FILE_HEADER.java")
public class ${NAME} {
}
#else
#parse("TABUYOS_LICENSE_HEADER.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("TABUYOS_FILE_HEADER.java")
public class ${NAME} {
}
#end
